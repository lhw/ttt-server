if SERVER then
   AddCSLuaFile( "shared.lua" )
   resource.AddFile("materials/VGUI/ttt/lykrast/icon_minifier.vmt")
end

if( CLIENT ) then
    SWEP.PrintName = "Minifier";
    SWEP.Slot = 7;
    SWEP.DrawAmmo = false;
    SWEP.DrawCrosshair = false;
    SWEP.Icon = "VGUI/ttt/lykrast/icon_minifier";
 
   SWEP.EquipMenuData = {
      type = "item_weapon",
      desc = "Activate it to become smaller\nbut more vulnerable."
   };

end

SWEP.Author= "Lykrast"


SWEP.Base = "weapon_tttbase"
SWEP.Spawnable= false
SWEP.AdminSpawnable= true
SWEP.HoldType = "slam"
 
SWEP.Kind = WEAPON_EQUIP2
SWEP.CanBuy = {ROLE_TRAITOR}
 
SWEP.ViewModelFOV= 60
SWEP.ViewModelFlip= false
SWEP.ViewModel      = "models/weapons/c_slam.mdl"
SWEP.WorldModel      = "models/weapons/w_slam.mdl"
SWEP.UseHands	= true
 
 --- PRIMARY FIRE ---
SWEP.Primary.Delay= 1
SWEP.Primary.Recoil= 0
SWEP.Primary.Damage= 0
SWEP.Primary.NumShots= 1
SWEP.Primary.Cone= 0
SWEP.Primary.ClipSize= -1
SWEP.Primary.DefaultClip= -1
SWEP.Primary.Automatic   = false
SWEP.Primary.Ammo         = "none"
SWEP.NoSights = true

function SWEP:Minify()
    self.Owner:SetModelScale( 0.5, 1 )
    if SERVER then self.Owner:SetMaxHealth( 50 ) end --beevis said so
    self.Owner:SetHealth( self.Owner:Health( ) * 0.5 )
    self.Owner:SetGravity( 1.5 )
    self.minified = true
end

function SWEP:UnMinify()
    self.Owner:SetModelScale( 1, 1 )
    if SERVER then self.Owner:SetMaxHealth( 100 ) end --beevis said so
    self.Owner:SetHealth( self.Owner:Health( ) * 2 )
    self.Owner:SetGravity( 1 )
    self.minified = false
end

function SWEP:PrimaryAttack()

self:SetNextPrimaryFire( CurTime() + self.Primary.Delay )

if ( self.minified ) then
    self:UnMinify()
else
    self:Minify()
end

end
 
function SWEP:PreDrop()

if ( self.minified ) then
    self:UnMinify()
end
 
end

hook.Add("TTTPrepareRound", "UnMinifyAll",function()
    for k, v in pairs(player.GetAll()) do
        v:SetModelScale( 1, 1 )
        v:SetGravity( 1 )
	v.minified = false
    end
end
)