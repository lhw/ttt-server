--[[---------------------------------------------------------
   Name:	KickId2
   Desc:	Allows admins to use the kickid2 command to kick people.
-----------------------------------------------------------]]
local function KickId( player, command, arguments )

	if ( !player:IsAdmin() ) then return end

	local id = arguments[1]
	local reason = arguments[2] or "Kicked"

	RunConsoleCommand( "kickid", id, Format( "%s (%s)", reason, player:Nick() ) );

end

concommand.Add( "kickid2", KickId, nil, "", { FCVAR_DONTRECORD } )


--[[---------------------------------------------------------
   Name:	BanId2
   Desc:	Allows admins to use the banid2 command to kick people.
-----------------------------------------------------------]]
local function BanID( player, command, arguments )

	if ( !player:IsAdmin() ) then return end

	local length 	= arguments[1]
	local id 		= arguments[2]

	RunConsoleCommand( "banid", length, id );

end

concommand.Add( "banid2", BanID, nil, "", { FCVAR_DONTRECORD } )

-- MAPS
resource.AddWorkshop( "157420728" ) -- ttt_waterworld
resource.AddWorkshop( "131667838" ) -- ttt_community-bowling
resource.AddWorkshop( "159321088" ) -- ttt_minecraft_b5
resource.AddWorkshop( "294357995" ) -- ttt_mw2_rust
resource.AddWorkshop( "253328815" ) -- ttt_skyscraper
resource.AddWorkshop( "295897079" ) -- ttt_lego
resource.AddWorkshop( "183797802" ) -- ttt_island_2013
resource.AddWorkshop( "335872739" ) -- ttt_Nuketown
resource.AddWorkshop( "253297309" ) -- ttt_airbus_b3
resource.AddWorkshop( "723778331" ) -- ttt_modern_house
resource.AddWorkshop( "294363438" ) -- ttt_mw2_scrapyard
resource.AddWorkshop( "534491717" ) -- ttt_rooftops_2016
resource.AddWorkshop( "147635981" ) -- ttt_forest_final
resource.AddWorkshop( "141103402" ) -- ttt_bb_teenroom_b2
resource.AddWorkshop( "176887855" ) -- ttt_mw2_terminal
resource.AddWorkshop( "131586546" ) -- ttt_bb_suburbia_b3
resource.AddWorkshop( "264839450" ) -- ttt_mcdonalds
resource.AddWorkshop( "186842624" ) -- ttt_minecraftcity_v4
resource.AddWorkshop( "106527577" ) -- ttt_lost_temple
resource.AddWorkshop( "371886156" ) -- ttt_terminus_v1
resource.AddWorkshop( "877419567" ) -- ttt_heaven
resource.AddWorkshop( "845646172" ) -- ttt_lagerhaus
resource.AddWorkshop( "118937144" ) -- ttt_lttp_kakariko
resource.AddWorkshop( "573496701" ) -- ttt_rivercliff
resource.AddWorkshop( "434164467" ) -- ttt_rooftops_a2
resource.AddWorkshop( "254061379" ) -- ttt_ski_resort_a4
resource.AddWorkshop( "442279607" ) -- ttt_vannah
resource.AddWorkshop( "299325283" ) -- silk_road_-_a_ttt_map
resource.AddWorkshop( "186012196" ) -- ttt_cruise
resource.AddWorkshop( "867635838" ) -- ttt_grovestreet
resource.AddWorkshop( "238575181" ) -- ttt_kakariko
resource.AddWorkshop( "248949639" ) -- ttt_mall
resource.AddWorkshop( "204080006" ) -- ttt_office_building
resource.AddWorkshop( "665994908" ) -- ttt_smallville_(wip)
resource.AddWorkshop( "808416533" ) -- ttt_subway_station
resource.AddWorkshop( "365484855" ) -- ttt_troubleisland
resource.AddWorkshop( "429578926" ) -- ttt_warehouses
resource.AddWorkshop( "177663377" ) -- ttt_stargate
resource.AddWorkshop( "345337612" ) -- ttt_concrete


-- ADDONS
resource.AddWorkshop( "356664308" ) -- [TTT] Melon Launcher
resource.AddWorkshop( "654767702" ) -- ttt_Taser (For Traitors)
resource.AddWorkshop( "284419411" ) -- TTT - Minifier
resource.AddWorkshop( "290945941" ) -- TTT - Door Locker
resource.AddWorkshop( "639521512" ) -- [ttt] Boomerang
resource.AddWorkshop( "236217898" ) -- TTT DeathFaker
resource.AddWorkshop( "645663146" ) -- [TTT/Sandbox] Sandwich (Medkit)
resource.AddWorkshop( "284418937" ) -- TTT - Jetpack
resource.AddWorkshop( "205723790" ) -- TTT - Portable Tester
resource.AddWorkshop( "711811322" ) -- TTT Flashbang
resource.AddWorkshop( "233067112" ) -- TTT Golden Gun
resource.AddWorkshop( "680737032" ) -- TTT Prop Exploder
resource.AddWorkshop( "282584080" ) -- TTT SpartanKick
resource.AddWorkshop( "106404821" ) -- TTT Traitor Turtlenade
resource.AddWorkshop( "194965598" ) -- TTT Weapon Collection
resource.AddWorkshop( "254107561" ) -- TTT Weapon Turret
resource.AddWorkshop( "481628210" ) -- Weapon Disabler Grenade (TTT)
resource.AddWorkshop( "254177306" ) -- [TTT] M4 SLAM (Tripmine + Remote C4)
resource.AddWorkshop( "415871359" ) -- BioBall - TTT
resource.AddWorkshop( "114582895" ) -- TTT - End Round Music
resource.AddWorkshop( "337994500" ) -- Lykrast's TTT Weapon Collection
resource.AddWorkshop( "810154456" ) -- TTT Dead Ringer
resource.AddWorkshop( "606792331" ) -- TTT Advanced Disguiser
resource.AddWorkshop( "620936792" ) -- TTT Homing Pigeon
resource.AddWorkshop( "496324857" ) -- John Cena Jihad Bomb (TTT)
resource.AddWorkshop( "173955637" ) -- TTT Cannibalism
resource.AddWorkshop( "742768877" ) -- TTT Decoy Weapon SWEP
resource.AddWorkshop( "755748551" ) -- TTT Jarate
resource.AddWorkshop( "609007212" ) -- TTT Toxin Pack
resource.AddWorkshop( "763129841" ) -- TTT Waffenkollektion
resource.AddWorkshop( "262136502" ) -- TTT Slow Motion (ZedTime)
resource.AddWorkshop( "648957314" ) -- TTT Homerun Bat
resource.AddWorkshop( "837635377" ) -- TTT Grapple Hook V2 (+Fix)
resource.AddWorkshop( "650523765" ) -- [TTT] Hermes Boots (Passive Perk)
resource.AddWorkshop( "273623128" ) -- Zombies Perk Bottles (TTT/Sandbox)
resource.AddWorkshop( "519467202" ) -- TTT_Explosive_Barrel_placer
resource.AddWorkshop( "233967112" ) -- ttt_ManhackSpawner
resource.AddWorkshop( "265678425" ) -- TTT_BrainParasite